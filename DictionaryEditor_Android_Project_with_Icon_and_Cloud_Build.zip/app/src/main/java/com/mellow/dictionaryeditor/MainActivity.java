package com.mellow.dictionaryeditor;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    private JSONObject dictionary;
    private String sourceName = "";
    private int addedCount = 0;
    private LinearLayout root, content;
    private TextView fileLabel, countLabel, addedLabel, searchResult, addStatus;
    private EditText searchInput, addInput;
    private Button searchButton, addButton, downloadButton, replaceButton;
    private static final int PICK_JSON = 10, SAVE_JSON = 11;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUI();
        loadSaved();
        refreshState();
    }

    private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private TextView text(String s,int size,int color){ TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t; }
    private int C(String h){ return android.graphics.Color.parseColor(h); }
    private GradientDrawable bg(String color,String stroke){ GradientDrawable d=new GradientDrawable();d.setColor(C(color));d.setCornerRadius(dp(14));d.setStroke(dp(1),C(stroke));return d; }
    private void buildUI(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(C("#090B10"));
        root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(18),dp(24),dp(18),dp(28));scroll.addView(root);
        TextView title=text("Dictionary Editor",24,C("#EEF2F8"));title.setTypeface(null,1);root.addView(title);
        TextView sub=text("FAST SEARCH  ·  ADD WORD  ·  JSON EXPORT",11,C("#8E9AAB")); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.bottomMargin=dp(20);root.addView(sub,sp);

        LinearLayout importCard=card(); root.addView(importCard);
        importCard.addView(heading("YOUR DICTIONARY"));
        fileLabel=text("No JSON file selected. Import a JSON file to begin.",13,C("#AAB4C5"));importCard.addView(fileLabel);
        LinearLayout row=new LinearLayout(this);row.setOrientation(0);row.setPadding(0,dp(12),0,0);importCard.addView(row);
        replaceButton=button("Choose / Replace JSON",true);row.addView(replaceButton,new LinearLayout.LayoutParams(-1,dp(48)));
        replaceButton.setOnClickListener(v->pickJson());

        LinearLayout searchCard=card();LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(14);root.addView(searchCard,cp);
        searchCard.addView(heading("FAST WORD SEARCH"));
        searchInput=input("Type a word to search");searchCard.addView(searchInput);
        searchButton=button("Search",true);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(46));bp.topMargin=dp(9);searchCard.addView(searchButton,bp);
        searchResult=text("Exact match first; otherwise checks shorter prefixes.",13,C("#9AA6B8"));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(12);searchCard.addView(searchResult,rp);
        searchButton.setOnClickListener(v->search());searchInput.setOnEditorActionListener((v,a,e)->{search();return true;});

        LinearLayout addCard=card();cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(14);root.addView(addCard,cp);
        addCard.addView(heading("ADD WORD"));
        addInput=input("Enter one word");addCard.addView(addInput);
        addButton=button("Add Word",true);bp=new LinearLayout.LayoutParams(-1,dp(46));bp.topMargin=dp(9);addCard.addView(addButton,bp);
        addStatus=text("",12,C("#75D6A2"));rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(9);addCard.addView(addStatus,rp);
        addButton.setOnClickListener(v->addWord());addInput.setOnEditorActionListener((v,a,e)->{addWord();return true;});

        LinearLayout stats=card();cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(14);root.addView(stats,cp);
        stats.addView(heading("DICTIONARY STATUS"));countLabel=text("Words: —",16,C("#EEF2F8"));stats.addView(countLabel);
        addedLabel=text("Added this session: 0",12,C("#9AA6B8"));stats.addView(addedLabel);

        downloadButton=button("Download Updated JSON",true);cp=new LinearLayout.LayoutParams(-1,dp(52));cp.topMargin=dp(14);root.addView(downloadButton,cp);
        downloadButton.setOnClickListener(v->saveJson());
        setContentView(scroll);
    }
    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(dp(16),dp(16),dp(16),dp(16));l.setBackground(bg("#141A26","#283244"));return l;}
    private TextView heading(String s){TextView t=text(s,13,C("#DCE4F5"));t.setTypeface(null,1);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(11);t.setLayoutParams(p);return t;}
    private EditText input(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(C("#EEF2F8"));e.setHintTextColor(C("#758195"));e.setHint(hint);e.setTextSize(14);e.setPadding(dp(13),0,dp(13),0);e.setBackground(bg("#090D14","#303A4B"));return e;}
    private Button button(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setAllCaps(false);b.setTextColor(primary?C("#0A1020"):C("#DCE4F5"));b.setBackground(bg(primary?"#9AABFF":"#1A2230",primary?"#9AABFF":"#354156"));return b;}
    private void pickJson(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,PICK_JSON);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null||data.getData()==null)return;
        if(req==PICK_JSON){Uri u=data.getData();try{String raw=readUri(u);JSONObject obj=new JSONObject(raw);if(obj.length()==0)throw new Exception("JSON object is empty.");dictionary=obj;sourceName=queryName(u);addedCount=0;saveSaved();refreshState();searchResult.setText("Loaded successfully. Search is ready.");addStatus.setText("Dictionary loaded: "+sourceName);}catch(Exception ex){toast("Invalid JSON: "+ex.getMessage());}}
        else if(req==SAVE_JSON){Uri u=data.getData();try(OutputStream os=getContentResolver().openOutputStream(u)){if(os==null)throw new IOException("Cannot open destination");os.write(dictionary.toString(2).getBytes(StandardCharsets.UTF_8));os.flush();toast("Updated JSON saved.");}catch(Exception ex){toast("Save failed: "+ex.getMessage());}}
    }
    private String readUri(Uri u)throws Exception{InputStream is=getContentResolver().openInputStream(u);if(is==null)throw new IOException("Cannot open file");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[65536];int n;while((n=is.read(buf))!=-1)out.write(buf,0,n);is.close();return new String(out.toByteArray(),StandardCharsets.UTF_8);}
    private String queryName(Uri u){String name=u.getLastPathSegment();if(name==null)name="selected.json";int i=name.lastIndexOf(':');if(i>=0)name=name.substring(i+1);return name;}
    private void search(){if(dictionary==null){toast("Import a JSON file first.");return;}String q=searchInput.getText().toString().trim().toLowerCase(Locale.ROOT);if(q.isEmpty()){searchResult.setText("Enter a word to search.");return;}
        if(dictionary.has(q)){searchResult.setText("EXACT MATCH\n"+q);return;}
        for(int i=q.length()-1;i>0;i--){String p=q.substring(0,i);if(dictionary.has(p)){searchResult.setText("LONGEST EXISTING PREFIX\n"+p+"\n“"+q+"” was not found.");return;}}
        searchResult.setText("NOT FOUND\nNo exact word or shorter prefix exists.");
    }
    private void addWord(){if(dictionary==null){toast("Import a JSON file first.");return;}String w=addInput.getText().toString().trim().toLowerCase(Locale.ROOT);
        if(w.isEmpty()){addStatus.setText("Enter a word first.");return;}if(w.matches(".*\\s+.*")){addStatus.setText("Only one word is allowed.");return;}
        if(dictionary.has(w)){addStatus.setText("Duplicate prevented: "+w+" already exists.");return;}
        try{dictionary.put(w,1);addedCount++;addInput.setText("");addStatus.setText("Added successfully: "+w);saveSaved();refreshState();}catch(Exception e){addStatus.setText("Could not add word.");}
    }
    private void saveJson(){if(dictionary==null){toast("Import a JSON file first.");return;}Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"dictionary_updated.json");startActivityForResult(i,SAVE_JSON);}
    private void saveSaved(){try(FileOutputStream f=openFileOutput("dictionary.json",MODE_PRIVATE)){f.write(dictionary.toString().getBytes(StandardCharsets.UTF_8));f.flush();}catch(Exception ignored){}}
    private void loadSaved(){try{File f=new File(getFilesDir(),"dictionary.json");if(f.exists()){ByteArrayOutputStream o=new ByteArrayOutputStream();try(FileInputStream in=openFileInput("dictionary.json")){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)o.write(b,0,n);}dictionary=new JSONObject(new String(o.toByteArray(),StandardCharsets.UTF_8));sourceName="Previously imported JSON";}}catch(Exception ignored){dictionary=null;}}
    private void refreshState(){boolean loaded=dictionary!=null;fileLabel.setText(loaded?"Loaded: "+sourceName:"No JSON file selected. Import a JSON file to begin.");countLabel.setText("Words: "+(loaded?String.format(Locale.US,"%,d",dictionary.length()):"—"));addedLabel.setText("Added this session: "+addedCount);searchButton.setEnabled(loaded);addButton.setEnabled(loaded);downloadButton.setEnabled(loaded);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
