# Dictionary Editor Android

## Build APK using GitHub Actions (no computer required)
1. Create a new GitHub repository from your Android phone.
2. Upload the **contents** of this project to the repository root. Keep `.github/workflows/build-apk.yml` (enable showing hidden files if your file manager hides `.github`).
3. Open the repository's **Actions** tab.
4. Select **Build Dictionary Editor APK**, then tap **Run workflow**.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run, find **Artifacts**, and download `DictionaryEditor-debug-apk`.
7. Extract the downloaded artifact ZIP; install `app-debug.apk` on your Android phone.

The APK is a debug-signed build for personal installation. It is not a Play Store release.
